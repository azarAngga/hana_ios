import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListCutiPage } from './list-cuti';

@NgModule({
  declarations: [
    ListCutiPage,
  ],
  imports: [
    IonicPageModule.forChild(ListCutiPage),
  ],
})
export class ListCutiPageModule {}
